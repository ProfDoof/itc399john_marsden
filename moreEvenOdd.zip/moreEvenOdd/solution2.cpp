#include <iostream>
using namespace std;

int main()
{
    int pos = 0;
    int num;

    while( true )
    {
        cout << "Number: ";
        cin >> num;

        if( num == 0 )
            break;
        // Add one if even, subtract one if odd
        if( num % 2 == 0 )
            pos++;
        else
            pos--;

        // Even more fun...
        //pos += ( (num % 2 == 0) * 2 - 1);
    }
	
    if( pos > 0 )
        cout << "Even\n";
    else if( pos == 0 )
        cout << "Equal\n";
    else // ( pos < 0 )
        cout << "Odd\n";
}


