#include <iostream>
using namespace std;

int main()
{
    int even = 0, odd = 0;
    int num;

    cout << "Number: ";
    cin >> num;

    while( num != 0 )
    {
        if( num % 2 == 0 )
            even++;
        else
            odd++;

        cout << "Number: ";
        cin >> num;
    }

    if( even > odd )
        cout << "Even\n";
    else if( even == odd )
        cout << "Equal\n";
    else // ( pos < neg )
        cout << "Odd\n";
}
